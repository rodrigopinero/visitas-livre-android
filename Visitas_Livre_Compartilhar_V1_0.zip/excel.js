/* Gerador XLSX inteiramente offline: ZIP (store) + OpenXML; preserva nomes como texto. */
(function(){
 'use strict';
 const enc = new TextEncoder();
 function bytes(s){return enc.encode(s)}
 function xml(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;')}
 const lut = (()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let j=0;j<8;j++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);t[n]=c>>>0;}return t})();
 function crc32(d){let c=0xffffffff;for(let k=0;k<d.length;k++)c=lut[(c^d[k])&255]^(c>>>8);return(c^0xffffffff)>>>0}
 function col(n){let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s}
 function excelDate(v){if(!/^\d{4}-\d\d-\d\d$/.test(String(v))) return null;return Math.round((Date.parse(v+'T00:00:00Z')-Date.UTC(1899,11,30))/86400000)}
 function sheetXml(rows, widths, dateColumns){
   const max=Math.max(1,...rows.map(r=>r.length));
   const cols=(widths || []).map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${Number(w)||15}" customWidth="1"/>`).join('');
   const body=rows.map((arr,r)=>`<row r="${r+1}">${arr.map((value,c)=>{
    if(value===null || value===undefined || value==='')return '';
    const ref=col(c)+(r+1);
    if(r>0 && dateColumns && dateColumns.includes(c)) {
      const day=excelDate(value);
      if(day!==null) return `<c r="${ref}" s="2"><v>${day}</v></c>`;
    }
    if(typeof value==='number' && Number.isFinite(value))return `<c r="${ref}"${r===0?' s="1"':''}><v>${value}</v></c>`;
    return `<c r="${ref}" s="${r===0?1:0}" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>`;
   }).join('')}</row>`).join('');
   return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${col(max-1)}${rows.length}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="17"/><cols>${cols}</cols><sheetData>${body}</sheetData><autoFilter ref="A1:${col(max-1)}${rows.length}"/></worksheet>`;
 }
 function concat(parts){const out=new Uint8Array(parts.reduce((s,p)=>s+p.length,0));let off=0;for(const part of parts){out.set(part,off);off+=part.length}return out}
 function u16(n){return Uint8Array.of(n&255,(n>>8)&255)}
 function u32(n){return Uint8Array.of(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255)}
 function zip(files){
  const local=[],central=[];let offset=0;
  for(const [name,content] of Object.entries(files)){
   const n=bytes(name),d=bytes(content),crc=crc32(d);
   const lh=concat([u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(0),u32(crc),u32(d.length),u32(d.length),u16(n.length),u16(0),n,d]);
   const ch=concat([u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(0),u32(crc),u32(d.length),u32(d.length),u16(n.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),n]);
   local.push(lh);central.push(ch);offset+=lh.length;
  }
  const cd=concat(central);
  const end=concat([u32(0x06054b50),u16(0),u16(0),u16(central.length),u16(central.length),u32(cd.length),u32(offset),u16(0)]);
  return new Blob([...local,cd,end],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
 }
 function exportXlsx(sheetDefinitions){
  const files={}; const rels=[]; const sheets=[]; const types=[];
  sheetDefinitions.forEach((def,i)=>{
   const idx=i+1; const safeName=String(def.name).substring(0,31).replace(/[\[\]*/?:\\]/g,'_');
   sheets.push(`<sheet name="${xml(safeName)}" sheetId="${idx}" r:id="rId${idx}"/>`);
   rels.push(`<Relationship Id="rId${idx}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${idx}.xml"/>`);
   types.push(`<Override PartName="/xl/worksheets/sheet${idx}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`);
   files[`xl/worksheets/sheet${idx}.xml`]=sheetXml(def.rows, def.widths, def.dateColumns);
  });
  rels.push(`<Relationship Id="rId${sheetDefinitions.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`);
  files['[Content_Types].xml']=`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${types.join('')}</Types>`;
  files['_rels/.rels']=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  files['xl/workbook.xml']=`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.join('')}</sheets></workbook>`;
  files['xl/_rels/workbook.xml.rels']=`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join('')}</Relationships>`;
  files['xl/styles.xml']=`<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="dd/mm/yyyy"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Aptos"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF123E40"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  return zip(files);
 }
 window.VisitExcel={exportXlsx};
})();
