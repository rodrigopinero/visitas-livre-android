/* Leitor XLSX local, sem CDN: abre somente abas de ruas e Extra Visitas.
   Usa os recursos ZIP/DEFLATE-RAW nativos de navegadores modernos. */
window.VisitImporter = (() => {
'use strict';
const decoder=new TextDecoder('utf-8');
const M='http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const FLAGS=['RN','DO','AC','DI','HA','GE','SM','BF','CV','CD'];
const numdate=n=>{const d=new Date(Date.UTC(1899,11,30)+Math.round(Number(n))*864e5);return Number.isFinite(d.getTime())?d.toISOString().slice(0,10):''};
function norm(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').toLowerCase().trim()}
function parseXml(str){const x=new DOMParser().parseFromString(str,'application/xml');if(x.getElementsByTagName('parsererror').length)throw Error('XML inválido na planilha');return x}
function zipEntries(buffer){
 const d=new DataView(buffer),a=new Uint8Array(buffer);let end=-1;
 for(let i=d.byteLength-22;i>=Math.max(0,d.byteLength-65557);i--){if(d.getUint32(i,true)===0x06054b50){end=i;break}}
 if(end<0)throw Error('Arquivo ZIP/XLSX inválido');
 let at=d.getUint32(end+16,true);const count=d.getUint16(end+10,true),files=new Map();
 for(let i=0;i<count;i++){
  if(d.getUint32(at,true)!==0x02014b50)throw Error('Diretório ZIP inválido');
  const method=d.getUint16(at+10,true),compressed=d.getUint32(at+20,true),uncompressed=d.getUint32(at+24,true),len=d.getUint16(at+28,true),extra=d.getUint16(at+30,true),comment=d.getUint16(at+32,true),local=d.getUint32(at+42,true);
  const name=decoder.decode(a.slice(at+46,at+46+len));files.set(name,{method,compressed,uncompressed,local});at+=46+len+extra+comment;
 }
 async function read(name){const entry=files.get(name);if(!entry)throw Error('Parte ausente do XLSX: '+name);
  const p=entry.local;if(d.getUint32(p,true)!==0x04034b50)throw Error('Entrada ZIP inválida');
  const start=p+30+d.getUint16(p+26,true)+d.getUint16(p+28,true);const bytes=a.subarray(start,start+entry.compressed);
  if(entry.method===0)return decoder.decode(bytes);
  if(entry.method!==8||typeof DecompressionStream==='undefined')throw Error('Seu navegador não consegue descompactar XLSX');
  const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return decoder.decode(await new Response(stream).arrayBuffer());
 }
 function entryStream(name){const entry=files.get(name);if(!entry)throw Error('Parte ausente do XLSX: '+name);
  const p=entry.local;if(d.getUint32(p,true)!==0x04034b50)throw Error('Entrada ZIP inválida');
  const start=p+30+d.getUint16(p+26,true)+d.getUint16(p+28,true);
  const payload=new Blob([a.subarray(start,start+entry.compressed)]).stream();
  if(entry.method===0)return payload;
  if(entry.method!==8||typeof DecompressionStream==='undefined')throw Error('Navegador não suporta descompactar o XLSX');
  return payload.pipeThrough(new DecompressionStream('deflate-raw'));
 }
 return {files,read,entryStream};
}
function strs(doc){const parts=doc.getElementsByTagNameNS(M,'si'),result=new Array(parts.length);for(let i=0;i<parts.length;i++){let text='';for(const t of parts[i].getElementsByTagNameNS(M,'t'))text+=t.textContent||'';result[i]=text}return result}
function parseRows(xml,shared,callback){const rows=xml.getElementsByTagNameNS(M,'row');let read=0;
 for(const row of rows){const obj={};for(const c of row.getElementsByTagNameNS(M,'c')){
  const col=(c.getAttribute('r')||'').match(/^[A-Z]+/)?.[0];if(!col)continue;
  const type=c.getAttribute('t');let value='';
  if(type==='inlineStr')value=c.getElementsByTagNameNS(M,'is')[0]?.textContent||'';
  else {value=c.getElementsByTagNameNS(M,'v')[0]?.textContent||'';if(type==='s')value=shared[Number(value)]||''}
  if(value!=='')obj[col]=String(value);
 }
 if(Object.keys(obj).length){callback(obj,Number(row.getAttribute('r'))||0);read++}
 }
 return read;
}
function columnHeaders(row){const obj={};for(const [k,v] of Object.entries(row))obj[norm(v)]=k;return obj}
function cell(row,head,...names){for(const n of names){const c=head[norm(n)];if(c&&row[c]!==undefined)return row[c]}return ''}
function nameOnly(principal){return /\d{15}$/.test(principal)?principal.slice(0,-15).trim():principal.trim()}
function iso(s){s=String(s||'').trim();if(!s)return '';if(/^\d{4}-\d\d-\d\d/.test(s))return s.slice(0,10);if(/^\d\d\/\d\d\/\d{4}$/.test(s)){const [d,m,y]=s.split('/');return `${y}-${m}-${d}`;}if(/^\d+(?:\.\d+)?$/.test(s))return numdate(s);return ''}
async function importWorkbook(file,progress=()=>{}){
 if(!file||!file.name.toLowerCase().endsWith('.xlsx'))throw Error('Selecione um arquivo .xlsx');
 if(file.size>80*1024*1024)throw Error('Arquivo acima do limite de 80 MB');
 progress('Abrindo a planilha…');const zip=zipEntries(await file.arrayBuffer());
 const workbook=parseXml(await zip.read('xl/workbook.xml'));
 const rels=parseXml(await zip.read('xl/_rels/workbook.xml.rels'));
 const relmap={};for(const rel of rels.getElementsByTagName('Relationship'))relmap[rel.getAttribute('Id')]=rel.getAttribute('Target');
 const sheets=[];
 for(const sheet of workbook.getElementsByTagNameNS(M,'sheet')){
  const name=sheet.getAttribute('name'),id=sheet.getAttributeNS(R,'id');let path=relmap[id];if(!path)continue;
  if(path.startsWith('/'))path=path.replace(/^\//,'');else if(!path.startsWith('xl/'))path='xl/'+path;
  sheets.push({name,path});
 }
 const streetSheets=sheets.filter(s=>!['dados identificacao','respostas ficha','metas','extra visitas'].includes(norm(s.name)));
 const extra=sheets.find(s=>norm(s.name)==='extra visitas');
 if(!streetSheets.length)throw Error('Nenhuma aba de rua encontrada nesta planilha');
 progress('Lendo nomes e identificadores…');let shared=[];
 if(zip.files.has('xl/sharedStrings.xml'))shared=strs(parseXml(await zip.read('xl/sharedStrings.xml')));
 const people=new Map(),houses=new Map(),streets=new Map(),history=[];let skipped=0,badId=0;
 async function parse(sheet,isExtra){progress(`Lendo aba ${sheet.name}…`);const xml=parseXml(await zip.read(sheet.path));let head=null;parseRows(xml,shared,(row,line)=>{
  if(!head){head=columnHeaders(row);return}
  const principal=cell(row,head,'Nome do Usuário','Principal');if(!principal){return}
  const streetName=isExtra?(cell(row,head,'Endereço')||'Extra Visitas'):sheet.name.trim();
  const number=cell(row,head,'Nº','Número').trim()||'S/N',originalComplement=cell(row,head,'Compl.','Complemento').trim(),complement=originalComplement||'Casa 1';
  const key=norm(streetName);if(!streets.has(key))streets.set(key,{id:'s'+(streets.size+1),name:streetName.trim()});
  const streetId=streets.get(key).id;const houseKey=streetId+'|'+norm(number)+'|'+norm(complement);
  if(!houses.has(houseKey))houses.set(houseKey,{id:'h'+(houses.size+1),streetId,number,complement,originalComplement});
  const houseId=houses.get(houseKey).id;
  const namestr=nameOnly(principal);if(!/\d{15}$/.test(principal))badId++;
  let p=people.get(principal);
  if(!p){p={id:'p'+(people.size+1),streetId,houseId,name:namestr,principal:String(principal),birth:iso(cell(row,head,'Nasc','Dt Nasc')),age:cell(row,head,'ID'),phone:cell(row,head,'Telefone'),cpf:cell(row,head,'CPF'),flags:{},sourceNotes:cell(row,head,'Observação'),sourceException:cell(row,head,'Exceção'),sourceExtra:cell(row,head,'Anotações')};
   for(const flag of FLAGS)p.flags[flag]=cell(row,head,flag);
   people.set(principal,p);
  }else{ // Preferir a ficha da rua original; só preenche campos vazios.
    for(const [key,val] of Object.entries({birth:iso(cell(row,head,'Nasc')),age:cell(row,head,'ID'),phone:cell(row,head,'Telefone'),cpf:cell(row,head,'CPF')}))if(!p[key]&&val)p[key]=val;
  }
  const date=iso(cell(row,head,'Data'));
  if(date){history.push({personPrincipal:principal,sourceKey:sheet.name+'|'+line,sourceSheet:sheet.name,date,status:'Importado',notes:cell(row,head,'Observação'),exception:cell(row,head,'Exceção'),extra:cell(row,head,'Anotações')});}
 });
 }
 for(const sheet of streetSheets){await parse(sheet,false);await new Promise(ok=>setTimeout(ok,0));}
 if(extra){await parse(extra,true)}
 progress('Organizando cadastros…');
 return {streets:[...streets.values()],houses:[...houses.values()],people:[...people.values()],history,sheets:streetSheets.map(s=>s.name),extra:!!extra,badId,skipped};
}
return {importWorkbook,numdate,nameOnly,FLAGS,openXlsx:zipEntries};
})();
