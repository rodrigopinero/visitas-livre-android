/* Edição independente: ruas são cadastradas pelo próprio usuário, sem lista predefinida. */
(function(global){'use strict';
 const KEY='visitas_livre_filtro_rua_v1';
 const LABELS=[];
 const norm=x=>String(x??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
 const streetKey=x=>norm(x);
 function updateStreets(streets){
  LABELS.splice(0,LABELS.length,...(streets||[]).filter(x=>x?.name&&streetKey(x.name)).map(s=>[streetKey(s.name),String(s.name).trim()]).sort((a,b)=>a[1].localeCompare(b[1],'pt-BR')));
 }
 function getFilter(){try{const s=localStorage.getItem(KEY)||'all';return s==='all'||LABELS.some(([id])=>id===s)?s:'all'}catch{return 'all'}}
 function setFilter(value){const v=value==='all'||LABELS.some(([id])=>id===value)?value:'all';try{localStorage.setItem(KEY,v)}catch{}return v}
 function matches(street,filter=getFilter()){return filter==='all'?!!streetKey(street):streetKey(street)===filter}
 function scope(source,filter=getFilter()){
  if(!source||filter==='all')return source;
  const streets=(source.streets||[]).filter(s=>matches(s.name,filter));
  const streetIds=new Set(streets.map(s=>s.id));
  const houses=(source.houses||[]).filter(h=>streetIds.has(h.streetId));
  const houseIds=new Set(houses.map(h=>h.id));
  const people=(source.people||[]).filter(p=>streetIds.has(p.streetId)||houseIds.has(p.houseId));
  const personIds=new Set(people.map(p=>p.id));
  const personMatch=r=>r&&personIds.has(r.personId);
  const visitMatch=v=>v&&(personMatch(v)||(!v.personId&&matches(v.streetSnapshot,filter)));
  const guideMatch=g=>g&&(g.personId?personMatch(g):matches(g.address||g.street,filter));
  return {...source,streets,houses,people,
   visits:(source.visits||[]).filter(visitMatch),
   consultations:(source.consultations||[]).filter(personMatch),
   deletedVisits:(source.deletedVisits||[]).filter(x=>visitMatch(x.visit)),
   duplicatePeople:(source.duplicatePeople||[]).filter(x=>streetIds.has(x?.person?.streetId)),
   duplicateVisits:(source.duplicateVisits||[]).filter(x=>visitMatch(x.visit)),
   tasks:(source.tasks||[]).filter(personMatch),
   attentionRecords:(source.attentionRecords||[]).filter(personMatch),
   guides:(source.guides||[]).filter(guideMatch),
   deletedGuides:(source.deletedGuides||[]).filter(x=>guideMatch(x?.guide||x)),
   areaNotes:(source.areaNotes||[]).filter(x=>!x?.personId||personMatch(x)),
   reminders:(source.reminders||[]).filter(x=>!x?.personId||personMatch(x))};
 }
 function matchesVisit(v,source,filter=getFilter()){
  const p=(source?.people||[]).find(p=>p.id===v?.personId);
  if(p){const st=(source.streets||[]).find(s=>s.id===p.streetId);const h=(source.houses||[]).find(h=>h.id===p.houseId);return matches(st?.name||(source.streets||[]).find(s=>s.id===h?.streetId)?.name,filter)}
  return matches(v?.streetSnapshot,filter);
 }
 global.VisitArea={LABELS,norm,streetKey,updateStreets,getFilter,setFilter,matches,scope,matchesVisit};
})(window);
