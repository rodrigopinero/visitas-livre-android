/* Visitas 3.8.0 — ajustes manuais por morador, sem apagar histórico ou reescrever a planilha. */
window.VisitGroups = (() => {
  'use strict';
  const groups = [
    ['HA','Hipertenso(a)'], ['DI','Diabético(a)'], ['GE','Gestante'], ['PU','Puérpera (até 30 dias após o parto)'],
    ['DO','Domiciliado(a)'], ['AC','Acamado(a)'],
    ['RN','Recém-nascido (0–30 dias)'], ['CRIANCA','Criança até 10 anos'],
    ['IDOSO','Idoso(a) (60+)']
  ];
  const ids = new Set(groups.map(([id]) => id));
  const hasOwn = (obj, key) => Object.prototype.hasOwnProperty.call(obj || {}, key);
  function override(p, group) {
    const entry = p?.groupOverrides?.[group];
    if (!ids.has(group) || !hasOwn(p?.groupOverrides,group)) return null;
    if (typeof entry === 'boolean') return entry;
    if (entry && typeof entry.value === 'boolean') return entry.value;
    return null;
  }
  function active(p, group, fallback) {
    const selected=override(p,group);
    return selected===null ? !!fallback : selected;
  }
  function setGroups(p, chosen, original) {
    if (!p || !Array.isArray(chosen)) throw new Error('Seleção de grupos inválida.');
    const chosenIds=new Set(chosen);
    if ([...chosenIds].some(id=>!ids.has(id))) throw new Error('Grupo de acompanhamento desconhecido.');
    const at=new Date().toISOString();
    p.groupOverrides ||= {};
    for (const [group] of groups) {
      const value=chosenIds.has(group);
      const previous=override(p,group);
      // Só criar uma decisão manual se ela mudar o valor calculado, ou preservar a decisão anterior.
      if (previous===null && value===!!original[group]) continue;
      if (previous===value) continue;
      p.groupOverrides[group]={value,at};
    }
    p.groupOverridesUpdatedAt=at;
    p.updatedAt=at;
  }
  function merge(target, from) {
    if (!target || !from?.groupOverrides) return;
    target.groupOverrides ||= {};
    for (const [group, incoming] of Object.entries(from.groupOverrides)) {
      if (!ids.has(group)) continue;
      const iValue=typeof incoming==='boolean'? incoming : incoming?.value;
      if (typeof iValue!=='boolean') continue;
      const current=target.groupOverrides[group];
      const incomingTime=typeof incoming==='object' ? (incoming.at||from.groupOverridesUpdatedAt||'') : (from.groupOverridesUpdatedAt||'');
      const currentTime=typeof current==='object' ? (current.at||target.groupOverridesUpdatedAt||'') : (target.groupOverridesUpdatedAt||'');
      if (!hasOwn(target.groupOverrides,group) || incomingTime>currentTime) {
        target.groupOverrides[group]={value:iValue,at:incomingTime};
      }
    }
    if(String(from.groupOverridesUpdatedAt||'')>String(target.groupOverridesUpdatedAt||''))target.groupOverridesUpdatedAt=from.groupOverridesUpdatedAt;
  }
  function exportFlag(p,group) {
    const selected=override(p,group);
    if(selected===null)return String(p?.flags?.[group]??'');
    return selected ? '1' : '';
  }
  function exportFlags(p) {
    const out={...(p?.flags||{})};
    for(const [group] of groups)if(hasOwn(out,group) || ['HA','DI','GE','DO','AC','RN'].includes(group))out[group]=exportFlag(p,group);
    return out;
  }
  return {groups,ids,override,active,setGroups,merge,exportFlag,exportFlags};
})();
