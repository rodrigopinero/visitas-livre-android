/* Visitas 3.8.9 — unificação conservadora das ruas da área.
   Altera APENAS ruas/casas e vínculos de endereço. Não altera fichas clínicas,
   CNS, visitas, consultas, guias ou seus registros históricos. */
(function(global){'use strict';
 const area=global.VisitArea;
 const labels=new Map(area.LABELS);
 const norm=area.norm;
 const streetKey=name=>area.streetKey(name);
 const identity=name=>streetKey(name)?'area:'+streetKey(name):'other:'+norm(name);
 const numberKey=value=>{
  const x=norm(value).replace(/^(?:n|no|numero)\s+/,'').trim();
  // "00102" e "102" são o mesmo número; "102 A" é outro endereço.
  return /^\d+$/.test(x)?String(Number(x)):x;
 };
 const complementKey=value=>norm(String(value||'Casa 1'));
 const houseKey=h=>[h.streetId,numberKey(h.number),complementKey(h.complement)].join('|');
 function consolidate(data){
  if(!data||!Array.isArray(data.streets)||!Array.isArray(data.houses)||!Array.isArray(data.people))throw Error('Base incompleta: ruas, casas ou moradores ausentes.');
  const original={streets:data.streets.length,houses:data.houses.length,people:data.people.length,visits:(data.visits||[]).length,consultations:(data.consultations||[]).length,guides:(data.guides||[]).length};
  const originalStreetIds=new Set(data.streets.map(s=>s.id)),originalHouseIds=new Set(data.houses.map(h=>h.id));
  const initiallyMissingHouses=new Set(data.houses.filter(h=>!originalStreetIds.has(h.streetId)).map(h=>h.id));
  const initiallyMissingPeople=new Set(data.people.filter(p=>!originalStreetIds.has(p.streetId)||!originalHouseIds.has(p.houseId)).map(p=>p.id));
  const groups=new Map(),streetAliases=new Map(),houseAliases=new Map();
  let renamed=0;
  // Unificar somente nomes equivalentes após normalização.
  for(const street of data.streets){
   const id=streetKey(street.name);
   if(!id)continue;
   const arr=groups.get(id)||[];arr.push(street);groups.set(id,arr);
  }
  for(const [key,items] of groups){
   const canonicalName=labels.get(key)||items[0].name;
   const winner=items.find(x=>x.name===canonicalName)||items[0];
   if(winner.name!==canonicalName){winner.name=canonicalName;renamed++}
   for(const extra of items){if(extra.id!==winner.id)streetAliases.set(extra.id,winner.id)}
  }
  for(const h of data.houses){h.streetId=streetAliases.get(h.streetId)||h.streetId}
  for(const p of data.people){p.streetId=streetAliases.get(p.streetId)||p.streetId}
  if(streetAliases.size)data.streets=data.streets.filter(s=>!streetAliases.has(s.id));
  // Mesma rua + número + complemento: uma residência. Complementos distintos
  // permanecem separados (ex.: Casa 1, Casa 2, fundos, apartamento).
  const byHouse=new Map();
  for(const h of data.houses){
   // S/N ou número ausente não identifica uma residência com segurança.
   const number=numberKey(h.number),isAmbiguous=!number||['s n','sn','sem numero','0','nao informado','s numero'].includes(number);
   const k=isAmbiguous?'UNIQUE:'+h.id:houseKey(h),canonical=byHouse.get(k);
   if(!canonical){byHouse.set(k,h);continue}
   if(canonical.id===h.id)continue;
   houseAliases.set(h.id,canonical.id);
   if(!canonical.originalComplement&&h.originalComplement)canonical.originalComplement=h.originalComplement;
  }
  if(houseAliases.size)data.houses=data.houses.filter(h=>!houseAliases.has(h.id));
  const houseById=new Map(data.houses.map(h=>[h.id,h]));
  const streetIds=new Set(data.streets.map(st=>st.id));
  for(const p of data.people){
   p.houseId=houseAliases.get(p.houseId)||p.houseId;
   const h=houseById.get(p.houseId);
   // O endereço da casa é a fonte de verdade para o vínculo territorial.
   if(h&&p.streetId!==h.streetId)p.streetId=h.streetId;
  }
  // Outras coleções podem guardar streetId / houseId (sem histórico textual).
  // Preservar nomes e snapshots originais de visitas para auditoria.
  const skip=new Set(['streets','houses','people','duplicatePeople','duplicateVisits','deletedVisits','visits','consultations','guideRestorations']);
  for(const [field,rows] of Object.entries(data)){
   if(skip.has(field)||!Array.isArray(rows))continue;
   for(const row of rows){
    if(!row||typeof row!=='object')continue;
    if(row.streetId&&streetAliases.has(row.streetId))row.streetId=streetAliases.get(row.streetId);
    if(row.houseId&&houseAliases.has(row.houseId))row.houseId=houseAliases.get(row.houseId);
   }
  }
  // Invariantes: nenhuma pessoa, visita, consulta ou guia pode desaparecer.
  if(data.people.length!==original.people||(data.visits||[]).length!==original.visits||(data.consultations||[]).length!==original.consultations||(data.guides||[]).length!==original.guides)throw Error('Proteção: a unificação não pode remover pessoas ou históricos.');
  if(data.houses.some(h=>!streetIds.has(h.streetId)&&!initiallyMissingHouses.has(h.id)))throw Error('Proteção: residência perdeu vínculo com sua rua.');
  if(data.people.some(p=>(!streetIds.has(p.streetId)||!houseById.has(p.houseId))&&!initiallyMissingPeople.has(p.id)))throw Error('Proteção: morador perdeu vínculo com seu endereço.');
  const report={before:original.streets,after:data.streets.length,mergedStreets:streetAliases.size,mergedHouses:houseAliases.size,renamed,
   people:data.people.length,visits:(data.visits||[]).length,consultations:(data.consultations||[]).length,guides:(data.guides||[]).length};
  report.changed=!!(report.mergedStreets||report.mergedHouses||renamed);
  return report;
 }
 global.VisitStreets={identity,consolidate,streetKey};
})(window);
