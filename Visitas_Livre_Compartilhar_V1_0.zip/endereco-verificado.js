/* Compartilhável: sem endereços corrigidos de terceiros, hashes ou dados originais. */
window.VisitAddressAudit=(()=>{'use strict';
 const normalize=x=>String(x??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
 const known=async()=>null;
 const correctSource=async doc=>doc;
 function getHouse(data,streetName,number,complement='Casa 1'){
  let street=data.streets.find(s=>normalize(s.name)===normalize(streetName));
  if(!street){street={id:crypto.randomUUID(),name:streetName};data.streets.push(street)}
  let house=data.houses.find(h=>h.streetId===street.id&&normalize(h.number)===normalize(number)&&normalize(h.complement||'Casa 1')===normalize(complement||'Casa 1'));
  if(!house){house={id:crypto.randomUUID(),streetId:street.id,number:String(number),complement:complement||'Casa 1'};data.houses.push(house)}
  return {street,house};
 }
 function relocate(data,p,streetName,number,complement='Casa 1',reason='manual'){
  const oldHouse=data.houses.find(h=>h.id===p.houseId),oldStreet=data.streets.find(s=>s.id===p.streetId),dst=getHouse(data,streetName,number,complement);
  const changed=p.houseId!==dst.house.id||p.streetId!==dst.street.id;
  if(changed){
   if(oldHouse&&oldStreet){p.addressHistory||=[];
    const last=p.addressHistory[p.addressHistory.length-1];
    const prev={street:oldStreet.name,number:oldHouse.number,complement:oldHouse.complement||'Casa 1',changedAt:new Date().toISOString(),reason};
    if(!last||last.street!==prev.street||last.number!==prev.number||last.complement!==prev.complement)p.addressHistory.push(prev)
   }
   p.streetId=dst.street.id;p.houseId=dst.house.id;
  }
  if(changed)p.verifiedAddress={street:dst.street.name,number:dst.house.number,complement:dst.house.complement,source:reason,verifiedAt:new Date().toISOString()};
  return changed;
 }
 const correctDatabase=async()=>0;
 return {known,correctSource,correctDatabase,relocate};
})();
