/* Visitas V3.1.2 — atualização segura do PWA no iOS.
   Nunca remove IndexedDB/localStorage; gerencia somente o cache de arquivos estáticos.
   O Safari/WebKit não aceita respostas de navegação redirecionadas entregues por SW.
*/
const CACHE_NAME = 'visitas-livre-v1-ruas-dinamicas';
const APP_ROOT = new URL('./', self.registration.scope).href;
const ASSETS = [
  './',
  './index.html',
  './grupos-v381.js',
  './grupos-v381.css',
  './grupos-v382.css',
  './recursos-v384.css',
  './consultas-v385.css',
  './puerperas-v388.css',
  './visitas-dia-v390.css',
  './styles-v324.css',
  './desktop-v325.css',
  './iphone-v352.css',
  './app-v382.js',
  './ruas-v389.js',
  './base-nova-v383.js',
  './endereco-verificado.js',
  './datagrid-v391.js',
  './datagrid-campos.css','./indicadores-ruas-v395.css',
  './area-v360.js',
  './area-v360.css',
  './controle-v370.js',
  './controle-v370.css',
  './duplicates-v350.js',
  './pwa-init.js',
  './visitas-integracao-v324.js',
  './visitas-integracao-v324.css',
  './xlsx-reader.js',
  './excel.js',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/agente-saude.svg'
];
const ASSET_URLS = new Set(ASSETS.map(path => new URL(path, APP_ROOT).href));

// Remove os metadados de redirecionamento antes de salvar ou entregar uma resposta.
// O corpo e o tipo de conteúdo permanecem inalterados.
function responseWithoutRedirect(response) {
  const headers = new Headers(response.headers);
  headers.delete('content-length');
  headers.delete('content-encoding');
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}

function isSafeStaticResponse(response) {
  if (!response.ok || response.type === 'opaque' || response.type === 'opaqueredirect') return false;
  try {
    return new URL(response.url).origin === self.location.origin;
  } catch (_) {
    return false;
  }
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const outcomes = await Promise.allSettled(ASSETS.map(async path => {
      const url = new URL(path, APP_ROOT).href;
      const response = await fetch(url, {cache: 'reload', redirect: 'follow'});
      if (!isSafeStaticResponse(response)) throw new Error('Arquivo indisponível: ' + path);
      await cache.put(url, responseWithoutRedirect(response));
    }));
    // Só substitui o SW antigo se a página principal estiver disponível offline.
    if (outcomes[0].status !== 'fulfilled') throw outcomes[0].reason;
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key =>
      key !== CACHE_NAME && (key.startsWith('visitas-livre-'))
    ).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

async function serveNavigation(request) {
  const cache = await caches.open(CACHE_NAME);
  try {
    const network = await fetch(request, {cache: 'no-store', redirect: 'follow'});
    if (!isSafeStaticResponse(network)) throw new Error('Navegação indisponível');
    // Compatível também com atalhos antigos cujo start_url ainda é /index.html.
    const clean = responseWithoutRedirect(network);
    const target = new URL(request.url);
    if (target.pathname === new URL(APP_ROOT).pathname || target.pathname === new URL('index.html', APP_ROOT).pathname) {
      // A falha ao atualizar o cache não deve bloquear o aplicativo online.
      await cache.put(APP_ROOT, clean.clone()).catch(() => {});
    }
    return clean;
  } catch (_) {
    const offlinePage = await cache.match(APP_ROOT);
    if (offlinePage) return responseWithoutRedirect(offlinePage);
    return Response.error();
  }
}

async function serveStatic(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request, {ignoreSearch: true});
  if (cached) return responseWithoutRedirect(cached);
  try {
    const network = await fetch(request, {redirect: 'follow'});
    if (!isSafeStaticResponse(network)) return network;
    const clean = responseWithoutRedirect(network);
    await cache.put(request, clean.clone()).catch(() => {});
    return clean;
  } catch (_) {
    return Response.error();
  }
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith(serveNavigation(request));
  } else if (ASSET_URLS.has(url.origin + url.pathname)) {
    event.respondWith(serveStatic(request));
  }
  // APIs e arquivos externos não entram no cache: Dados privados ficam somente no cofre local.
});
