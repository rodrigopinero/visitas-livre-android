/* Deduplicação reversível (somente aplicativo Linux). Nenhum registro é apagado sem cópia. */
(function(global){'use strict';
const text=v=>String(v??'');
const validCns=principal=>{const m=text(principal).match(/(\d{15})$/);return m?m[1]:''};
const personKey=p=>validCns(p?.principal);
const visitKey=(v,personById)=>{
 if(!['Presente','Ausente'].includes(v?.status)||!/\d{4}-\d{2}-\d{2}/.test(v.date||'')||v.keepDuplicate===true)return '';
 const cns=personKey(personById.get(v.personId))||validCns(v.principalSnapshot);
 return cns?cns+'|'+v.date:'';
};
const isConfirmed=v=>['confirmada','duplicada'].includes(v?.fastmedic?.state);
const sortCanonicalVisit=(a,b)=>Number(isConfirmed(b))-Number(isConfirmed(a))||text(a.createdAt).localeCompare(text(b.createdAt))||text(a.id).localeCompare(text(b.id));
function normalize(db){
 db.duplicatePeople ||= [];db.duplicateVisits ||= [];
 const canonical=new Map(),aliases=new Map(),removed=[];let people=0,visits=0;
 for(const p of db.people||[]){
  const key=personKey(p);
  if(!key){continue}
  if(!canonical.has(key)){canonical.set(key,p);continue}
  const main=canonical.get(key);
  if(p.id===main.id)continue;
  aliases.set(p.id,main.id);
  if(!db.duplicatePeople.some(x=>x?.person?.id===p.id))db.duplicatePeople.push({person:structuredClone(p),canonicalId:main.id,reason:'Cartão SUS repetido',archivedAt:new Date().toISOString()});
  // Não sobrescrever dados existentes; preservar cópia integral no arquivo de duplicados.
  for(const field of ['birth','phone','cpf','age','motherName','deliveryDate','sourceNotes','sourceException','sourceExtra'])if(!main[field]&&p[field])main[field]=p[field];
  main.flags={...p.flags,...main.flags};
  if(global.VisitGroups)global.VisitGroups.merge(main,p);
  removed.push(p.id);people++;
 }
 if(removed.length){
  const removedSet=new Set(removed);db.people=db.people.filter(p=>!removedSet.has(p.id));
  for(const type of ['visits','tasks','guides','areaNotes','reminders','attentionRecords','consultations'])for(const r of db[type]||[]){if(aliases.has(r.personId))r.personId=aliases.get(r.personId)}
  for(const r of db.deletedVisits||[])if(aliases.has(r?.visit?.personId))r.visit.personId=aliases.get(r.visit.personId);
  for(const r of db.duplicateVisits||[])if(aliases.has(r?.visit?.personId))r.visit.personId=aliases.get(r.visit.personId);
 }
 const byId=new Map((db.people||[]).map(p=>[p.id,p]));
 const groups=new Map();
 for(const v of db.visits||[]){const k=visitKey(v,byId);if(!k)continue;const arr=groups.get(k)||[];arr.push(v);groups.set(k,arr)}
 const archiveIds=new Set();
 for(const group of groups.values()){
  if(group.length<2)continue;
  group.sort(sortCanonicalVisit);
  const main=group[0];
  for(const v of group.slice(1)){
   if(db.duplicateVisits.some(x=>x?.visit?.id===v.id)){archiveIds.add(v.id);visits++;continue}
   const p=byId.get(v.personId);
   db.duplicateVisits.push({visit:structuredClone(v),name:p?.name||'',canonicalVisitId:main.id,reason:'Mesmo Cartão SUS e mesma data',archivedAt:new Date().toISOString()});
   archiveIds.add(v.id);visits++;
  }
 }
 if(archiveIds.size)db.visits=db.visits.filter(v=>!archiveIds.has(v.id));
 return {people,visits,changed:people>0||visits>0};
}
function archivedFastMedic(db){
 db.duplicateVisits ||= [];
 const archiveIds=new Set();let count=0;
 for(const v of db.visits||[]){
  if(v.fastmedic?.state!=='duplicada'||v.fastmedic?.revision!==[v.updatedAt||v.createdAt||'',v.date,v.status,v.notes||'',v.exception||'',v.extra||''].join('|'))continue;
  if(db.duplicateVisits.some(x=>x?.visit?.id===v.id))continue;
  const p=(db.people||[]).find(p=>p.id===v.personId);
  db.duplicateVisits.push({visit:structuredClone(v),name:p?.name||'',canonicalVisitId:'',reason:'Já registrado no FastMedic',archivedAt:new Date().toISOString()});
  archiveIds.add(v.id);count++;
 }
 if(count)db.visits=db.visits.filter(v=>!archiveIds.has(v.id));
 return count;
}
function importArchive(target,source){
 target.duplicatePeople ||= [];target.duplicateVisits ||= [];
 for(const [key,sub] of [['duplicatePeople','person'],['duplicateVisits','visit']]){
  const have=new Set(target[key].map(x=>x?.[sub]?.id));
  for(const item of source[key]||[]){const id=item?.[sub]?.id;if(!id||have.has(id))continue;target[key].push(structuredClone(item));have.add(id)}
 }
}
global.VisitDuplicates={normalize,archivedFastMedic,importArchive,validCns};
})(window);
