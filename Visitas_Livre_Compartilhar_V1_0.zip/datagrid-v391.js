/* Visitas iPhone 3.9.1 — DataGrid Cadastro + Respostas offline.
   Não envia planilhas à internet. Identifica arquivos pelo cabeçalho, não pelo nome.
   Lê as linhas gradualmente para evitar armazenar mais de 100 MB de XML no iPhone. */
window.VisitDataGrid = (()=>{
 'use strict';
 const nf=x=>String(x??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const val=x=>String(x??'').trim();
 const cns=x=>val(x).replace(/\D/g,'');
 const escXml=s=>String(s??'').replace(/&(?:amp|lt|gt|quot|apos|#(?:x[0-9a-f]+|\d+));/gi,e=>{
  const m={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"};const v=e.slice(1,-1);if(v[0]==='#'){
   const num=v[1]?.toLowerCase()==='x'?parseInt(v.slice(2),16):Number(v.slice(1));
   return Number.isInteger(num)&&num>0&&num<=0x10ffff?String.fromCodePoint(num):'';
  }return m[v.toLowerCase()]??e;
 });
 const validStreet=s=>val(s);
 function sharedStrings(xml){const out=[];const si=/<si\b[^>]*>([\s\S]*?)<\/si>/g;let m;while((m=si.exec(xml))){
  let content='';const t=/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g;let z;while((z=t.exec(m[1])))content+=escXml(z[1]);out.push(content);
 }return out}
 function readRow(xml,shared){const values={};const cell=/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g;let m;
  while((m=cell.exec(xml))){if(m[2]===undefined)continue;const col=/\br="([A-Z]+)\d+"/.exec(m[1])?.[1];if(!col)continue;
   const type=/\bt="([^"]+)"/.exec(m[1])?.[1]||'';
   let value='';if(type==='inlineStr'){
    const t=/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g;let q;while((q=t.exec(m[2])))value+=escXml(q[1]);
   }else{const v=/<v\b[^>]*>([\s\S]*?)<\/v>/.exec(m[2]);if(v)value=type==='s'?shared[Number(v[1])]??'':escXml(v[1]);}
   if(value!=='')values[col]=value;
  }
  return values;
 }
 async function readXlsx(file,progress){
  if(!file||!/\.xlsx$/i.test(file.name))throw Error('Escolha arquivos Excel .xlsx.');
  if(file.size>25*1024*1024)throw Error('Cada planilha pode ter no máximo 25 MB.');
  progress('Identificando a planilha '+file.name+'…');
  const zip=window.VisitImporter.openXlsx(await file.arrayBuffer());
  if(!zip.files.has('xl/worksheets/sheet1.xml'))throw Error('Planilha sem primeira aba: '+file.name);
  const compressed=zip.files.get('xl/worksheets/sheet1.xml');
  if(compressed.uncompressed>110*1024*1024)throw Error('Planilha acima do limite de processamento local.');
  const s=zip.files.has('xl/sharedStrings.xml')?zip.files.get('xl/sharedStrings.xml'):null;
  if(s?.uncompressed>20*1024*1024)throw Error('Dicionário XLSX muito grande.');
  const shared=s?sharedStrings(await zip.read('xl/sharedStrings.xml')):[];
  const stream=zip.entryStream('xl/worksheets/sheet1.xml');
  const reader=stream.getReader(),decoder=new TextDecoder('utf-8');let buffer='',rows=0,kind='',headers=null,columns={},records=[];
  function consumeRow(markup){
   const row=readRow(markup,shared);rows++;
   if(rows===1){headers={};for(const [col,title] of Object.entries(row)){const name=nf(title);if(name){headers[name]=col;columns[col]=title}};
    if(!headers['cartao sus']||!headers['nome']||!headers['endereco'])throw Error('Cabeçalhos DataGrid obrigatórios ausentes em '+file.name);
    if(headers['dsc latitude']&&headers['cpf'])kind='cadastro';
    else if(headers['esta gestante ?']&&headers['tem hipertensao arterial ?'])kind='respostas';
    else throw Error('Não foi possível identificar cadastro ou respostas em '+file.name);
    return;
   }
   const get=k=>val(row[headers[nf(k)]||'']);const street=validStreet(get('Endereço'));
   if(!street||!get('Nome'))return;
   const origem={},values={};for(const [col,raw] of Object.entries(row))if(columns[col]){origem[columns[col]]=raw;values[nf(columns[col])]=val(raw)}
   records.push({linha:rows,rua:street,origem,values});
  }
  function consume(text){buffer+=text;let end;
   while((end=buffer.indexOf('</row>'))>=0){
    const start=buffer.indexOf('<row ');if(start<0||start>end+6){buffer=buffer.slice(end+6);continue}
    consumeRow(buffer.slice(start,end+6));buffer=buffer.slice(end+6);
   }
   // Sem linha aberta, não manter o cabeçalho / rodapé de XML em memória.
   if(!buffer.includes('<row ')&&buffer.length>256)buffer=buffer.slice(-128);
   if(buffer.length>3*1024*1024)throw Error('Linha XLSX acima do limite de segurança.');
  }
  try{let count=0;while(true){const {value,done}=await reader.read();if(done)break;consume(decoder.decode(value,{stream:true}));if((++count%45)===0){progress('Lendo '+file.name+' · '+rows.toLocaleString('pt-BR')+' linhas…');await new Promise(ok=>setTimeout(ok,0));}}consume(decoder.decode());}
  finally{reader.releaseLock()}
  if(!kind||rows<2)throw Error('Planilha vazia ou sem dados: '+file.name);
  return {kind,records,rows,file:file.name};
 }
 const get=(r,key)=>r?.values?.[nf(key)]||'';
 const iso=s=>{
  s=val(s);if(!s)return '';
  if(/^\d{4}-\d\d-\d\d/.test(s))return s.slice(0,10);
  if(/^\d\d\/\d\d\/\d{4}$/.test(s)){const [d,m,y]=s.split('/');return `${y}-${m}-${d}`}
  if(/^\d+(?:\.\d+)?$/.test(s))return window.VisitImporter.numdate(s);
  return '';
 };
 function compose(cadastros,respostas){
  const profile=r=>[nf(get(r,'Nome')),iso(get(r,'Dt Nasc')),nf(get(r,'Mãe')),nf(r.rua),nf(get(r,'Número')||'S/N'),nf(get(r,'Complemento')||'Casa 1')].join('|');
  const responseByCns=new Map(),noCnsAnswers=new Map(),audit=[];for(const r of respostas){const key=cns(get(r,'Cartão SUS'));if(/^\d{15}$/.test(key)){if(!responseByCns.has(key))responseByCns.set(key,[]);responseByCns.get(key).push(r)}else if(!key){const k=profile(r);if(!noCnsAnswers.has(k))noCnsAnswers.set(k,[]);noCnsAnswers.get(k).push(r)}}
  const pending=[],active=[],keys=new Map(),badCns=new Set(),collisions=new Map();
  const flags={GE:'Está gestante ?',HA:'Tem hipertensão arterial ?',DI:'Tem diabetes ?',AC:'Está acamado ?',DO:'Está domiciliado ?'};
  for(const r of cadastros){
   const sus=cns(get(r,'Cartão SUS')),name=get(r,'Nome'),mom=get(r,'Mãe'),birth=iso(get(r,'Dt Nasc'));
   const street=r.rua,number=get(r,'Número')||'S/N',complement=get(r,'Complemento')||'Casa 1';
   const matches=!sus?noCnsAnswers.get(profile(r))||[]:[];const responseOptions=/^\d{15}$/.test(sus)?(responseByCns.get(sus)||[]):matches;
   let resp=responseOptions.length===1?responseOptions[0]:null;
   const addressMismatch=!!resp&&(nf(get(resp,'Endereço'))!==nf(get(r,'Endereço'))||nf(get(resp,'Número'))!==nf(get(r,'Número'))||nf(get(resp,'Complemento')||'Casa 1')!==nf(get(r,'Complemento')||'Casa 1'));
   const identityMismatch=!!resp&&(nf(get(resp,'Nome'))!==nf(name)||iso(get(resp,'Dt Nasc'))!==birth);
   if(responseOptions.length>1)audit.push({tipo:'respostas-duplicadas',linhaCadastro:r.linha,linhasResposta:responseOptions.map(x=>x.linha)});
   if(addressMismatch)audit.push({tipo:'endereco-divergente',linhaCadastro:r.linha,linhaResposta:resp.linha});
   if(identityMismatch){audit.push({tipo:'identidade-divergente',linhaCadastro:r.linha,linhaResposta:resp.linha});resp=null}

   const group={};for(const [k,field] of Object.entries(flags))group[k]=resp?get(resp,field):'';
   const tel=['Celular','Telefone','Telefone Contato','Telefone Dom'].map(k=>get(r,k)).find(Boolean)||'';
   const item={id:'cns:'+sus,cns:sus,nome:name,nascimento:birth,rua:street,numero:number,complemento:complement,
    nome_mae:mom,cpf:get(r,'CPF'),telefone:tel,situacao_cadastro:get(r,'Situação Cadastro'),ultima_visita:'',grupos:group,
    tem_resposta:!!resp,situacao_ficha_resposta:resp?'presente':'ausente',
    respostas:resp?Object.fromEntries(Object.entries(resp.origem).filter(([,v])=>!!v)):{'__estado_ficha_resposta':'AUSENTE'},
    linha_cadastro:r.linha,linha_resposta:resp?.linha??null,cadastro_origem:r.origem,resposta_origem:resp?.origem??{},addressNeedsReview:addressMismatch};
   if(!/^\d{15}$/.test(sus)){
    const pendingRecord={...item,id:'sem-cns:'+r.linha,status:'pendente-cns',motivo:'Cartão SUS não informado nos dados de origem'};
    pendingRecord.pendingKey=window.VisitBaseNova.provisionalKey(pendingRecord);
    pending.push(pendingRecord);continue;
   }
   const key=[nf(name),nf(mom),birth,nf(street),nf(number),nf(complement)].join('|');
   if(!keys.has(key))keys.set(key,[]);keys.get(key).push(item);
   if(!collisions.has(sus))collisions.set(sus,[]);collisions.get(sus).push(item);
   active.push(item);
  }
  const duplicates=[],reserved=new Set();for(const group of keys.values()){
   const uniq=[...new Set(group.map(x=>x.cns))];if(uniq.length<2)continue;uniq.forEach(x=>reserved.add(x));
   const p=group[0];duplicates.push({id:'dup:'+(duplicates.length+1),status:'a-conferir',
    motivo:'CNS distintos para a mesma combinação de nome, mãe, nascimento e endereço',
    nome:p.nome,nascimento:p.nascimento,rua:p.rua,numero:p.numero,complemento:p.complemento,nome_mae:p.nome_mae,
    cns_encontrados:uniq.sort(),linhas_cadastro:group.map(x=>x.linha_cadastro),tem_resposta:group.some(x=>x.tem_resposta),candidatos:group});
  }
  // CNS idêntico em fichas conflitantes nunca é associado a um paciente diferente sem conferência.
  for(const [sus,group] of collisions){
   if(group.length<2)continue;
   const signatures=new Set(group.map(p=>[nf(p.nome),nf(p.nome_mae),p.nascimento].join('|')));
   if(signatures.size<2||reserved.has(sus))continue;reserved.add(sus);
   duplicates.push({id:'dup:'+(duplicates.length+1),status:'a-conferir',
    motivo:'Mesmo CNS associado a dados pessoais diferentes',nome:group[0].nome,cns_encontrados:[sus],
    linhas_cadastro:group.map(p=>p.linha_cadastro),candidatos:group});
  }
  const seen=new Set(),people=[];for(const p of active){if(reserved.has(p.cns)||seen.has(p.cns))continue;seen.add(p.cns);people.push(p)}
  return {formato:'visitas-6-ruas-v1',versao_base:'2.1',fontes:['DataGrid de cadastro','DataGrid de respostas'],
   resumo:{cadastros_area_origem:cadastros.length,respostas_area_origem:respostas.length,
    cadastros_ativos:people.length+pending.length,cadastros_ativos_sem_cns:pending.length,cadastros_ativos_com_cns_e_resposta:people.filter(p=>p.tem_resposta).length,
    cadastros_ativos_com_cns_sem_resposta:people.filter(p=>!p.tem_resposta).length,
    pendencias_sem_cns:pending.length,suspeitas_duplicidade:duplicates.length,
    registros_reservados_por_duplicidade:reserved.size,alertas_dados:audit.length},
   auditoria:{alertas:audit},pessoas:people.concat(pending),pendencias_cns:pending,duplicidades:duplicates};
 }
 async function importFiles(files,progress=()=>{}){
  const arr=Array.from(files||[]);if(arr.length!==2||arr.some(f=>!/\.xlsx$/i.test(f.name)))throw Error('Selecione as duas planilhas DataGrid .xlsx juntas.');
  progress('Lendo as duas planilhas Excel, sem enviar dados à internet…');
  const a=await readXlsx(arr[0],progress),b=await readXlsx(arr[1],progress);
  if(a.kind===b.kind)throw Error('As duas planilhas são do mesmo tipo. Selecione Cadastro e Respostas.');
  const cadastro=a.kind==='cadastro'?a:b,respostas=a.kind==='respostas'?a:b;
  progress('Vinculando cadastros às fichas de respostas pelo CNS…');
  const doc=compose(cadastro.records,respostas.records);
  progress('Validando moradores, endereços e duplicidades…');
  return await window.VisitBaseNova.importData(doc,progress);
 }
 return {readXlsx,compose,importFiles};
})();
