/* Edição compartilhável: somente preferências de interface, sem qualquer integração Google. */
let vSettings={bar:0,gestures:true};
try{vSettings={...vSettings,...JSON.parse(localStorage.getItem('visitas-livre-ui-prefs')||'{}')}}catch(_){ }
function vStore(){localStorage.setItem('visitas-livre-ui-prefs',JSON.stringify(vSettings))}
function vBar(value){vSettings.bar=Math.max(-120,Math.min(300,Math.round(Number(value)||0)));vStore();document.documentElement.style.setProperty('--visitas-bar-offset',vSettings.bar+'px');const slider=document.getElementById('v-nav-slider'),label=document.getElementById('v-nav-label');if(slider)slider.value=vSettings.bar;if(label)label.textContent=vSettings.bar+'px'}
vBar(vSettings.bar);
document.addEventListener('click',e=>{const id=e.target.closest('button')?.id;if(!id)return;const actions={'v-nav-minus':()=>vBar(vSettings.bar-10),'v-nav-plus':()=>vBar(vSettings.bar+10),'v-nav-reset':()=>vBar(0)};if(actions[id]){e.preventDefault();actions[id]()}});
document.addEventListener('input',e=>{if(e.target.id==='v-nav-slider')vBar(e.target.value)});
document.addEventListener('change',e=>{if(e.target.id==='v-nav-gestures'){vSettings.gestures=e.target.checked;vStore()}});
const vObserver=new MutationObserver(()=>{const x=document.getElementById('v-nav-slider');if(x&&x.value!==String(vSettings.bar))x.value=vSettings.bar;const y=document.getElementById('v-nav-label');if(y)y.textContent=vSettings.bar+'px';const g=document.getElementById('v-nav-gestures');if(g)g.checked=vSettings.gestures});vObserver.observe(document.getElementById('app'),{childList:true,subtree:false});
// Swipe de navegação: área de início ampliada, sem interferir em rolagem vertical.
// Esquerda -> guia anterior; direita -> próxima guia.
let vTouch=null;
const vPages=['home','streets','attention','groups','guides','more'];
function vGestureStart(e){
 if(!vSettings.gestures||e.touches.length!==1)return;
 const t=e.touches[0],target=e.target;
 if(t.clientX>Math.min(90,innerWidth*.20)&&t.clientX<innerWidth-Math.min(90,innerWidth*.20))return;
 if(target.closest('input,textarea,select,button,[contenteditable="true"],[draggable="true"],.modal,[role="dialog"],.mobile-nav'))return;
 vTouch={x:t.clientX,y:t.clientY,edge:t.clientX<innerWidth/2?'left':'right',vertical:false};
}
function vGestureMove(e){
 if(!vTouch||!e.touches.length)return;
 const t=e.touches[0];
 if(Math.abs(t.clientY-vTouch.y)>Math.abs(t.clientX-vTouch.x)*1.2&&Math.abs(t.clientY-vTouch.y)>25)vTouch.vertical=true;
}
function vGestureEnd(e){
 if(!vTouch)return;
 const gesture=vTouch;vTouch=null;
 if(gesture.vertical||!vSettings.gestures||!e.changedTouches.length)return;
 const t=e.changedTouches[0],dx=t.clientX-gesture.x,dy=t.clientY-gesture.y;
 if(Math.abs(dy)>65||Math.abs(dx)<65||Math.abs(dx)<Math.abs(dy)*1.4)return;
 const idx=vPages.indexOf(window.VisitPublicNavigation?.page?.());
 if(gesture.edge==='left'&&dx>0&&idx>0)window.VisitPublicNavigation?.go?.(vPages[idx-1]);
 else if(gesture.edge==='right'&&dx<0&&idx>=0&&idx<vPages.length-1)window.VisitPublicNavigation?.go?.(vPages[idx+1]);
}
document.addEventListener('touchstart',vGestureStart,{passive:true,capture:true});
document.addEventListener('touchmove',vGestureMove,{passive:true,capture:true});
document.addEventListener('touchend',vGestureEnd,{passive:true,capture:true});
document.addEventListener('touchcancel',()=>{vTouch=null},{passive:true});

