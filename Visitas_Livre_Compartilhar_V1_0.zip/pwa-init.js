/* Registro seguro do PWA, sem limpar dados locais. */
if('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost')) {
  window.addEventListener('load',()=>{
    navigator.serviceWorker.register('./sw.js', {scope:'./'}).catch(err=>console.warn('Modo offline indisponível:',err));
  });
}
