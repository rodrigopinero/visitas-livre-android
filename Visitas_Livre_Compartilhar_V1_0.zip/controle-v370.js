/* Painel de Controle de Visitas 3.7.0. Dados somente em memória do cofre atual. */
(function(global){'use strict';
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtDate=d=>/^\d{4}-\d{2}-\d{2}$/.test(d||'')?d.slice(8,10)+'/'+d.slice(5,7):String(d||'');
const validDate=d=>/^\d{4}-\d{2}-\d{2}$/.test(String(d||''));
const eligible=v=>v && (v.status==='Presente'||v.status==='Ausente');
function monthDays(month){if(!/^\d{4}-\d{2}$/.test(month||''))return [];
 const [year,mm]=month.split('-').map(Number);const count=new Date(year,mm,0).getDate();
 return Array.from({length:count},(_,i)=>month+'-'+String(i+1).padStart(2,'0'));
}
function revision(v){return [v.updatedAt||v.createdAt||'',v.date,v.status,v.notes||'',v.exception||'',v.extra||''].join('|')}
function fastStatus(v){const result=v.fastmedic||{};
 if(result.revision===revision(v) && result.state==='confirmada')return 'confirmada';
 if(result.revision===revision(v) && result.state==='duplicada')return 'duplicada';
 if(result.revision===revision(v) && result.state==='erro')return 'erro';
 return 'pendente';
}
function getMetrics(db, opts={}){
 const month=String(opts.month||'');const platform=opts.platform==='linux'?'linux':'iphone';
 const people=new Map((db?.people||[]).map(p=>[p.id,p]));
 const streets=new Map((db?.streets||[]).map(s=>[s.id,s]));
 const homes=new Map((db?.houses||[]).map(h=>[h.id,h]));
 const rows=[];
 for(const v of db?.visits||[]){
  if(!validDate(v.date) || !String(v.date).startsWith(month) || v.status==='Importado')continue;
  const p=people.get(v.personId),home=homes.get(p?.houseId);
  const st=streets.get(p?.streetId)||streets.get(home?.streetId);
  const streetName=st?.name||v.streetSnapshot||'Não informada';
  const streetKey=global.VisitArea?.streetKey?.(streetName)||'';
  const mark=platform==='linux'?(eligible(v)?fastStatus(v):'outro'):'local';
  rows.push({id:v.id||'',name:p?.name||'Morador',date:v.date,status:v.status,mark,street:streetName,streetKey,notes:v.notes||''});
 }
 rows.sort((a,b)=>b.date.localeCompare(a.date)||String(b.id).localeCompare(String(a.id)));
 const valid=rows.filter(r=>eligible(r));
 const activity=platform==='linux'?valid.filter(r=>r.mark==='confirmada'):rows;
 const present=activity.filter(r=>r.status==='Presente').length;
 const absent=activity.filter(r=>r.status==='Ausente').length;
 const other=activity.length-present-absent;
 const pending=platform==='linux'?valid.filter(r=>r.mark==='pendente').length:0;
 const errors=platform==='linux'?valid.filter(r=>r.mark==='erro').length:0;
 const duplicates=platform==='linux'?valid.filter(r=>r.mark==='duplicada').length:0;
 const byStreet=(db?.streets||[]).slice().sort((a,b)=>a.name.localeCompare(b.name,'pt-BR')).map(st=>({key:global.VisitArea.streetKey(st.name),label:st.name,count:activity.filter(r=>r.streetKey===global.VisitArea.streetKey(st.name)).length}));
 const byDay=monthDays(month).map(day=>({day,count:activity.filter(r=>r.date===day).length}));
 const archived=[];
 if(platform==='linux')for(const entry of db?.duplicateVisits||[]){
  const v=entry?.visit;
  if(entry?.reason!=='Já registrado no FastMedic'||!v||!validDate(v.date)||!v.date.startsWith(month))continue;
  const p=people.get(v.personId),home=homes.get(p?.houseId),st=streets.get(p?.streetId)||streets.get(home?.streetId);
  const streetName=st?.name||v.streetSnapshot||'Não informada';
  archived.push({id:v.id||'',name:p?.name||entry.name||'Morador',date:v.date,status:v.status,mark:'duplicada',street:streetName,streetKey:global.VisitArea?.streetKey?.(streetName)||'',notes:v.notes||''});
 }
 const latest=rows.concat(archived).sort((a,b)=>b.date.localeCompare(a.date)||String(b.id).localeCompare(String(a.id))).slice(0,80);
 return {month,platform,rows,latest,activity,all:rows.length+archived.length,confirmed:activity.length,present,absent,other,pending,errors,duplicates:duplicates+archived.length,byStreet,byDay,peopleCount:db?.people?.length||0};
}
function statusLabel(mark){return ({confirmada:'Confirmada no FastMedic',duplicada:'Já existente',erro:'Falha no lançamento',pendente:'Aguardando lançamento',local:'Salva no aplicativo',outro:'Registro local'})[mark]||'Registro'}
function card(label,value,sub,variant=''){return `<div class="vc-stat ${variant}"><small>${escape(label)}</small><strong>${value}</strong><span>${escape(sub)}</span></div>`}
function bar(label,value,max,colour='',detail=''){
 const width=max?Math.max(0,Math.min(100,100*value/max)):0;
 return `<div class="vc-bar-row"><div class="vc-bar-titles"><span>${escape(label)}</span><b>${value}</b></div><div class="vc-bar-track"><div class="vc-bar-fill ${colour}" style="width:${width.toFixed(2)}%"></div></div>${detail?`<small>${escape(detail)}</small>`:''}</div>`;
}
function allStatusFilter(status){return ['all','Presente','Ausente','confirmada','pendente','erro','duplicada'].includes(status)?status:'all'}
function filteredRows(m,status){status=allStatusFilter(status);return m.latest.filter(r=>status==='all'||r.status===status||r.mark===status)}
function dailyBars(m){const entries=m.byDay, max=Math.max(1,...entries.map(r=>r.count));
 return `<div class="vc-day-chart" role="img" aria-label="Visitas por dia do mês">${entries.map(r=>`<div class="vc-day" title="Dia ${escape(fmtDate(r.day))}: ${r.count} visita(s)"><span class="vc-day-value">${r.count||''}</span><div class="vc-day-track"><div style="height:${Math.max(0,r.count/max*100).toFixed(2)}%"></div></div><small>${Number(r.day.slice(-2))%5===0||Number(r.day.slice(-2))===1?Number(r.day.slice(-2)):''}</small></div>`).join('')}</div>`;
}
function statusOptions(platform){return platform==='linux'?[['all','Todas'],['confirmada','Confirmadas'],['pendente','Pendentes'],['erro','Falhas'],['duplicada','Já existentes'],['Presente','Presentes'],['Ausente','Ausentes']]:[['all','Todas'],['Presente','Presentes'],['Ausente','Ausentes']]}
function page(db,opts={}){
 const m=getMetrics(db,opts),linux=m.platform==='linux';const status=allStatusFilter(opts.status||'all');const shown=filteredRows(m,status);const maxStreet=Math.max(1,...m.byStreet.map(r=>r.count));
 const labelledMonth=/^\d{4}-\d{2}$/.test(m.month)?m.month.slice(5)+'/'+m.month.slice(0,4):m.month;
 const modeText=linux?'Apenas confirmações válidas do FastMedic entram no total lançado. Visitas pendentes e com erro ficam separadas.':'Apenas visitas salvas no cofre deste aparelho. Não representa lançamentos feitos no FastMedic do computador.';
 const split=m.present+m.absent;const percent=split?Math.round(100*m.present/split):0;
 const mainCards=linux?card('Confirmadas',m.confirmed,'FastMedic • mês selecionado','is-main')+card('Pendentes',m.pending,'Aguardando lançamento','is-pending')+card('Falhas',m.errors,'Precisam de revisão','is-error')+card('Já existentes',m.duplicates,'Não somadas ao total','is-other'):
 card('Visitas lançadas',m.confirmed,'No aplicativo • mês','is-main')+card('Presentes',m.present,'Visitas com presença','is-present')+card('Ausentes',m.absent,'Visitas sem presença','is-pending')+card('Moradores',m.peopleCount,'Na área selecionada','is-other');
 return `<section class="vc-dashboard" aria-label="Controle gráfico de visitas">
 <div class="vc-heading"><div><div class="vc-eyebrow">MONITORAMENTO DA ÁREA</div><h1>Controle de Visitas</h1><p>Acompanhe seus registros por dia, resultado e rua.</p></div><span class="vc-period">${escape(labelledMonth)}</span></div>
 <div class="vc-toolbar"><label for="vc-month">Mês de referência<input id="vc-month" type="month" value="${escape(m.month)}"></label><label for="vc-status">Mostrar registros<select id="vc-status">${statusOptions(m.platform).map(([v,label])=>`<option value="${v}" ${status===v?'selected':''}>${label}</option>`).join('')}</select></label><button class="vc-history-button" type="button" data-nav="history">Abrir histórico</button></div>
 <div class="vc-stats">${mainCards}</div>
 <div class="vc-grids"><section class="vc-panel"><div class="vc-panel-heading"><h2>Presente × Ausente</h2><span>${m.present+m.absent} visitas</span></div><div class="vc-pie-row"><div class="vc-donut" style="--vc-fill:${percent}%" role="img" aria-label="${m.present} presentes, ${m.absent} ausentes"><div><strong>${percent}%</strong><small>presença</small></div></div><div class="vc-legend"><div><i class="is-present"></i><span>Presentes</span><b>${m.present}</b></div><div><i class="is-absent"></i><span>Ausentes</span><b>${m.absent}</b></div>${m.other?`<div><i class="is-other"></i><span>Outras</span><b>${m.other}</b></div>`:''}</div></div></section>
 <section class="vc-panel"><div class="vc-panel-heading"><h2>Visitas por rua</h2><span>${m.byStreet.reduce((n,r)=>n+r.count,0)} lançadas</span></div><div class="vc-streets">${m.byStreet.map(r=>bar(r.label,r.count,maxStreet)).join('')}</div></section></div>
 ${linux?`<section class="vc-panel vc-wide"><div class="vc-panel-heading"><h2>Evolução diária</h2><span>${escape(labelledMonth)}</span></div>${dailyBars(m)}</section>`:`<section class="vc-panel vc-day-mini"><div class="vc-panel-heading"><h2>Visitas por dia</h2><span>${escape(labelledMonth)}</span></div>${dailyBars(m)}</section>`}
 <section class="vc-panel vc-wide"><div class="vc-panel-heading"><h2>Últimos registros</h2><span>${shown.length} exibidos</span></div><div class="vc-table-scroll"><table class="vc-table"><thead><tr><th>Morador</th><th>Data</th><th>Rua</th><th>Situação</th>${linux?'<th>FastMedic</th>':''}</tr></thead><tbody>${shown.length?shown.slice(0,linux?50:12).map(r=>`<tr><td>${escape(r.name)}</td><td>${escape(fmtDate(r.date))}</td><td>${escape(r.street)}</td><td><span class="vc-chip ${r.status==='Ausente'?'is-absent':r.status==='Presente'?'is-present':'is-other'}">${escape(r.status)}</span></td>${linux?`<td><span class="vc-chip ${r.mark==='erro'?'is-error':r.mark==='confirmada'?'is-present':'is-other'}">${escape(statusLabel(r.mark))}</span></td>`:''}</tr>`).join(''):`<tr><td colspan="${linux?5:4}" class="vc-empty">Nenhuma visita encontrada para este filtro.</td></tr>`}</tbody></table></div><p class="vc-note">${escape(modeText)} ${m.all>m.latest.length?'A lista abaixo é limitada aos registros mais recentes.':''}</p></section>
 </section>`;
}
function teaser(db,opts={}){const m=getMetrics(db,opts);const label=m.platform==='linux'?'Confirmadas no FastMedic':'Lançadas no aplicativo';const sub=m.platform==='linux'?`${m.pending} pendente(s) · ${m.errors} falha(s)`:`${m.present} presente(s) · ${m.absent} ausente(s)`;
 return `<button type="button" class="vc-home-teaser" data-nav="controle" aria-label="Abrir Controle de Visitas"><span><small>CONTROLE DE VISITAS</small><strong>${m.confirmed} <em>${escape(label)}</em></strong><span>${escape(sub)}</span></span><span class="vc-home-arrow">Ver gráficos →</span></button>`;
}
global.VisitControl={getMetrics,fastStatus,page,teaser};
})(window);
