/* Adaptador de dados: base organizada com ruas livres, sem dados de pacientes embutidos.
   Retorna a mesma estrutura do importador XLSX da versão 3.8.2.
   Não altera armazenamento nem interface; o aplicativo decide se importa. */
window.VisitBaseNova = (()=>{'use strict';
const norm=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
const v=s=>String(s??'').trim();
function validDate(s){
 if(!s)return true;
 if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;
 const d=new Date(s+'T12:00:00Z');
 return Number.isFinite(d.valueOf())&&d.toISOString().slice(0,10)===s;
}
function expectedStreet(rua){return String(rua??'').trim();}
function flag(value){const n=norm(value);return ['sim','s','1','true'].includes(n)?'1':['nao','n','0','false'].includes(n)?'0':''}
async function importJson(file,progress=()=>{}){
 if(!file||!/\.json$/i.test(file.name))throw Error('Selecione a base organizada .json');
 if(file.size>20*1024*1024)throw Error('Base JSON acima de 20 MB.');
 progress('Conferindo formato e dados da base…');
 let source;try{source=JSON.parse(await file.text())}catch{throw Error('JSON inválido ou incompleto. Nenhum dado foi alterado.')}
 return importData(source,progress);
}
async function importData(source,progress=()=>{}){
 if(!['visitas-6-ruas-v1','visitas-ruas-livres-v1'].includes(source?.formato)||!Array.isArray(source?.pessoas))throw Error('Formato de base JSON não reconhecido.');
 await window.VisitAddressAudit.correctSource(source);
 if(source.pessoas.length===0)throw Error('A base está vazia.');
 const streets=new Map(),houses=new Map(),people=[],cnsSet=new Set(),pendingSet=new Set();
 const included=new Set(source.pessoas.filter(p=>p?.id).map(p=>String(p.id)));
 const extras=(source.pendencias_cns||[]).filter(p=>!included.has(String(p.id||'')));
 const input=source.pessoas.concat(extras);
 for(const [i,p] of input.entries()){ 
  const cns=v(p.cns),name=v(p.nome),streetLabel=expectedStreet(p.rua),birth=v(p.nascimento),number=v(p.numero)||'S/N',complement=v(p.complemento)||'Casa 1';
  const pending=!/^\d{15}$/.test(cns);
  if(pending && p.status!=='pendente-cns' && !p.pendingKey)throw Error(`Registro ${i+1}: identificação sem CNS sem marcação de pendência.`);
  if(pending && cns!=='')throw Error(`Registro ${i+1}: CNS incompleto; conferir antes de mesclar.`);
  if(!pending && cnsSet.has(cns))throw Error(`A base contém Cartão SUS repetido no registro ${i+1}. Importação cancelada.`);
  if(!name||!/[^\W\d_]/u.test(name)||/^\d+$/.test(name))throw Error(`Registro ${i+1}: nome ausente ou inválido.`);
  if(!streetLabel)throw Error(`Registro ${i+1}: rua não informada.`);
  if(!validDate(birth))throw Error(`Registro ${i+1}: nascimento inválido.`);
  if(p.respostas!==undefined&&(typeof p.respostas!=='object'||p.respostas===null||Array.isArray(p.respostas)))throw Error(`Registro ${i+1}: formato inválido de ficha de resposta.`);
  if(!pending)cnsSet.add(cns);
  const pendingKey=window.VisitBaseNova.provisionalKey(p);
  if(pending){if(pendingSet.has(pendingKey))throw Error(`Mais de um cadastro sem CNS com a mesma identificação no registro ${i+1}. Conferir origem.`);pendingSet.add(pendingKey)}
  const streetKey=norm(streetLabel);
  if(!streets.has(streetKey))streets.set(streetKey,{id:'s'+(streets.size+1),name:streetLabel});
  const streetId=streets.get(streetKey).id,houseKey=[streetId,norm(number),norm(complement)].join('|');
  if(!houses.has(houseKey))houses.set(houseKey,{id:'h'+(houses.size+1),streetId,number,complement,originalComplement:v(p.complemento)});
  const g=p.grupos||{};
  people.push({id:'p'+(people.length+1),streetId,houseId:houses.get(houseKey).id,
    name,principal:pending?name:name+' '+cns,birth,age:'',phone:v(p.telefone),cpf:v(p.cpf),
    cnsPending:pending,pendingKey,sourceStreet:streetLabel,sourceNumber:number,sourceComplement:complement,
    verifiedAddress:p.verifiedAddress||null,originalSourceAddress:p.originalSourceAddress||null,addressNeedsReview:!!p.addressNeedsReview,
    flags:{RN:'',DO:flag(g.DO),AC:flag(g.AC),DI:flag(g.DI),HA:flag(g.HA),GE:flag(g.GE),SM:'',BF:'',CV:'',CD:''},
    motherName:v(p.nome_mae),statusCadastro:v(p.situacao_cadastro),lastOfficialVisitReported:v(p.ultima_visita),
    healthResponses:p.tem_resposta===false?{}:structuredClone(p.respostas||{}),hasHealthResponse:p.tem_resposta===true,sourceCadastroLine:p.linha_cadastro,sourceRespostaLine:p.linha_resposta,
    sourceNotes:'',sourceExtra:''});
  if(i>0&&i%250===0){progress(`Validando ${i.toLocaleString('pt-BR')} cadastros…`);await new Promise(resolve=>setTimeout(resolve,0))}
 }
 progress('Base validada. Preparando a prévia para confirmação…');
 return {streets:[...streets.values()],houses:[...houses.values()],people,history:[],badId:0,
  meta:{kind:'nova-base',semCns:input.filter(p=>!v(p.cns)).length,
        duplicates:Array.isArray(source.duplicidades)?source.duplicidades.length:0,
        addressWarnings:Array.isArray(source?.auditoria?.alertas)?source.auditoria.alertas.length:0,
        ignored:source.resumo?.cadastros_sem_resposta_ignorados??null}};
}
function provisionalKey(p){
 const c=String(p.cpf||'').replace(/\D/g,''),name=norm(p.nome),birth=v(p.nascimento);
 return c.length===11?'cpf:'+c+'|nome:'+name+'|nasc:'+birth:
 ['perfil:'+name,'mae:'+norm(p.nome_mae),'nasc:'+birth].join('|');
}
return {importJson,importData,provisionalKey};
})();
